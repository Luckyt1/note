#!/usr/bin/env bash
set -euo pipefail

show_usage() {
  printf '%s\n' \
    'Usage: ./install.sh --vault /absolute/path/to/ObsidianVault [options]' \
    '' \
    'Options:' \
    '  --skill-root PATH  Personal skills directory.' \
    '                     Default: $CODEX_HOME/skills or $HOME/.agents/skills' \
    '  --no-enable        Install files without enabling the systemd timer.' \
    '  -h, --help         Show this help.'
}

vault_input=''
skill_root_input=''
enable_timer=1

while (($#)); do
  case "$1" in
    --vault)
      (($# >= 2)) || { show_usage >&2; exit 2; }
      vault_input=$2
      shift 2
      ;;
    --skill-root)
      (($# >= 2)) || { show_usage >&2; exit 2; }
      skill_root_input=$2
      shift 2
      ;;
    --no-enable)
      enable_timer=0
      shift
      ;;
    -h|--help)
      show_usage
      exit 0
      ;;
    *)
      printf 'Unknown argument: %s\n' "$1" >&2
      show_usage >&2
      exit 2
      ;;
  esac
done

[[ -n "$vault_input" ]] || { show_usage >&2; exit 2; }
command -v python3 >/dev/null || { printf 'python3 is required.\n' >&2; exit 1; }

vault_path=$(realpath "$vault_input")
[[ -d "$vault_path/.obsidian" ]] || {
  printf 'Not an Obsidian vault: %s\n' "$vault_path" >&2
  exit 1
}

if [[ -z "$skill_root_input" ]]; then
  if [[ -n "${CODEX_HOME:-}" ]]; then
    skill_root_input=$CODEX_HOME/skills
  else
    skill_root_input=$HOME/.agents/skills
  fi
fi

skill_root=$(realpath -m "$skill_root_input")
skill_dir=$skill_root/obsidian-project-note
unit_dir=$HOME/.config/systemd/user
bundle_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
service_target=$unit_dir/obsidian-project-note-merge.service
timer_target=$unit_dir/obsidian-project-note-merge.timer

for target in "$skill_dir" "$service_target" "$timer_target"; do
  [[ ! -e "$target" ]] || {
    printf 'Refusing to overwrite existing file or directory: %s\n' "$target" >&2
    printf 'Rename or back it up, then run the installer again.\n' >&2
    exit 1
  }
done

mkdir -p "$skill_root" "$unit_dir"
cp -a "$bundle_dir/payload/skill" "$skill_dir"
install -m 0644 \
  "$bundle_dir/payload/systemd/obsidian-project-note-merge.service" \
  "$service_target"
install -m 0644 \
  "$bundle_dir/payload/systemd/obsidian-project-note-merge.timer" \
  "$timer_target"

python3 - "$skill_dir" "$vault_path" "$service_target" <<'PY'
from pathlib import Path
import sys

skill_dir = Path(sys.argv[1])
vault = Path(sys.argv[2])
service = Path(sys.argv[3])
replacements = {
    "/home/tang/note/note": str(vault),
    "/home/tang/.codex/skills/obsidian-project-note": str(skill_dir),
}
files = [
    skill_dir / "SKILL.md",
    skill_dir / "scripts" / "save_note.py",
    skill_dir / "scripts" / "merge_notes.py",
    service,
]
for path in files:
    content = path.read_text(encoding="utf-8")
    for old, new in replacements.items():
        content = content.replace(old, new)
    path.write_text(content, encoding="utf-8")
PY

chmod 0755 "$skill_dir/scripts/save_note.py" "$skill_dir/scripts/merge_notes.py"
PYTHONDONTWRITEBYTECODE=1 python3 "$skill_dir/scripts/save_note.py" --help >/dev/null
PYTHONDONTWRITEBYTECODE=1 python3 "$skill_dir/scripts/merge_notes.py" --help >/dev/null

if ((enable_timer)); then
  command -v systemctl >/dev/null || {
    printf 'systemctl is required unless --no-enable is used.\n' >&2
    exit 1
  }
  systemctl --user daemon-reload
  systemctl --user enable --now obsidian-project-note-merge.timer
  if command -v loginctl >/dev/null; then
    loginctl enable-linger "$(id -un)" || \
      printf 'Warning: could not enable linger; the timer will run only while logged in.\n' >&2
  fi
fi

printf 'Installed skill: %s\n' "$skill_dir"
printf 'Obsidian vault: %s\n' "$vault_path"
if ((enable_timer)); then
  printf 'Hourly timer enabled. Restart Codex if the skill is not discovered immediately.\n'
else
  printf 'Timer not enabled (--no-enable).\n'
fi
