# Obsidian AI 项目笔记系统迁移包

这个迁移包用于恢复 `obsidian-project-note` Codex Skill 和每小时自动整理服务。AI 完成项目修改后会把笔记写入 `AI项目笔记/`；systemd 每小时按 `project` 合并到 `AI项目汇总/<项目>/项目汇总.md`，确认汇总成功后删除原笔记。

## 需要同步到云端的内容

建议直接同步整个 Obsidian 仓库。与本系统有关的目录是：

- `AI项目笔记/`：等待下一次整理的临时笔记。
- `AI项目汇总/`：按项目保存的长期数据。
- `AI项目笔记系统迁移包/`：本 README、压缩包和校验文件。

迁移压缩包不重复包含笔记数据；数据由前两个目录随 Obsidian 仓库一起同步。

## 重要：避免两台设备同时整理

同一个云同步仓库只能让一台设备启用 `obsidian-project-note-merge.timer`。迁移前先在旧设备执行：

```bash
systemctl --user disable --now obsidian-project-note-merge.timer
```

确认云端同步完成后，再在新设备安装并启用。云同步不提供跨设备文件锁，两台设备同时整理可能产生同步冲突。

## 新设备要求

- Linux，推荐 Ubuntu 22.04 或更新版本。
- Python 3.10 或更新版本。
- systemd 用户服务。
- Obsidian 1.12.7 或兼容更新版本。
- Codex。官方个人 Skill 目录是 `$HOME/.agents/skills`；若当前安装使用 `CODEX_HOME`，安装脚本会采用 `$CODEX_HOME/skills`。

## 已解压后的安装步骤

先在新设备安装 Obsidian 和 Codex，并打开或同步原来的 Obsidian 仓库。解压外层的 `obsidian-project-note-portable.tar.gz` 后，进入解压目录：

```bash
cd obsidian-project-note-portable
sha256sum -c MANIFEST.sha256
./install.sh --vault "/你的/Obsidian仓库"
```

如果新设备仍使用旧式 `$HOME/.codex/skills` 目录：

```bash
./install.sh --vault "/你的/Obsidian仓库" --skill-root "$HOME/.codex/skills"
```

安装器会：

1. 复制 Skill 与两个 Python 脚本。
2. 把旧设备路径替换成新设备的 Skill 和 Obsidian 仓库路径。
3. 安装并启用用户级 systemd timer。
4. 尝试启用 linger，使退出桌面登录后 timer 仍能运行。

安装器不会覆盖已有的同名 Skill、service 或 timer。如果任一目标已存在，先把它重命名为备份，再重新执行安装器。

## 验证

```bash
systemctl --user is-enabled obsidian-project-note-merge.timer
systemctl --user is-active obsidian-project-note-merge.timer
systemctl --user list-timers obsidian-project-note-merge.timer --all
```

预期前两条分别输出 `enabled` 和 `active`。可以手动触发一次整理：

```bash
systemctl --user start obsidian-project-note-merge.service
journalctl --user-unit obsidian-project-note-merge.service -n 20 --no-pager
```

如果 Codex 没有立即显示 Skill，重启 Codex。OpenAI 官方说明 Codex 会自动检测 Skill 变化，但部分情况下需要重启。

## 只安装文件、不启动定时器

用于测试或先检查配置：

```bash
./install.sh --vault "/你的/Obsidian仓库" --no-enable
```

之后手动启用：

```bash
systemctl --user daemon-reload
systemctl --user enable --now obsidian-project-note-merge.timer
```

## 数据安全设计

- 汇总文件通过同目录临时文件、原子替换和 `fsync` 写入。
- 原笔记只在汇总文件成功落盘后删除。
- 每篇原笔记带唯一来源标记，中断重试不会重复追加。
- 无法解析 `project` 的笔记保留在收集箱，不会自动删除。
- 保存脚本使用排他创建，多个 AI 同一秒写笔记也不会互相覆盖。

## 包内文件

```text
obsidian-project-note-portable/
├── README.md
├── install.sh
├── MANIFEST.sha256
└── payload/
    ├── skill/
    │   ├── SKILL.md
    │   ├── agents/openai.yaml
    │   └── scripts/
    │       ├── save_note.py
    │       └── merge_notes.py
    └── systemd/
        ├── obsidian-project-note-merge.service
        └── obsidian-project-note-merge.timer
```

OpenAI 官方文档：[Build skills](https://developers.openai.com/codex/skills)
